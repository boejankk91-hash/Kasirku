# Kasir Rumah Kopi — Android pribadi

Aplikasi kasir Android offline dengan identitas Rumah Kopi dan logo pengguna.

## Fitur
- Dashboard ringkasan omzet hari ini, transaksi, dan jumlah menu.
- Kasir, pencarian menu, filter kategori, keranjang, jumlah item.
- Pembayaran Tunai, Transfer, QRIS, dan Bayar nanti (pencatatan manual; tidak terhubung ke payment gateway).
- Hitung total dan kembalian.
- Preview struk sebelum cetak.
- Riwayat transaksi dan laporan bulanan.
- Kelola menu/harga/kategori.
- Pengaturan nama usaha.
- Penyimpanan lokal/offline.
- Cetak ESC/POS via Bluetooth Classic ke printer yang telah dipair; implementasi saat ini memakai perangkat paired pertama.

## Build melalui GitHub
1. Buat repository GitHub dan upload semua isi folder ini.
2. Buka tab **Actions**.
3. Jalankan **Build Kasir Rumah Kopi APK** (Run workflow), atau push ke branch `main`.
4. Setelah selesai, download artifact `Kasir-Rumah-Kopi-debug-apk`.
5. Ekstrak artifact, lalu instal `app-debug.apk` di Android.

## Build lokal
Gunakan Android Studio terbaru, JDK 17, Android SDK 35, dan Gradle 8.9. Buka folder proyek lalu jalankan `gradle assembleDebug`.

## Catatan
- Data transaksi disimpan pada perangkat, tidak tersinkron ke cloud. Buat backup berkala.
- Printer harus dipair melalui Settings Bluetooth Android terlebih dahulu. Untuk printer ESC/POS Bluetooth Classic, aplikasi mengirim struk ke perangkat paired pertama. Jika beberapa printer paired, unpair printer lain sebelum cetak.
- QRIS/transfer/bayar nanti hanya metode pencatatan; tidak memproses pembayaran otomatis.
- Ini build debug untuk pemakaian pribadi. APK release signed belum disiapkan.
