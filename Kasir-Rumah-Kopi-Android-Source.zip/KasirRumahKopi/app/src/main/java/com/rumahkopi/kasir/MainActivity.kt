package com.rumahkopi.kasir

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.io.OutputStream

private val Coffee = Color(0xFF4A210B)
private val Coffee2 = Color(0xFF7B3F16)
private val Cream = Color(0xFFFFF5DF)
private val Gold = Color(0xFFD9A72E)
private val Paper = Color(0xFFFFFBF3)
private val Ink = Color(0xFF3B1B0B)
private val Muted = Color(0xFF826B58)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { KasirApp(this) } }
}

data class Product(val id: String = UUID.randomUUID().toString(), val name: String, val category: String, val price: Long, val emoji: String = "☕")
data class CartLine(val product: Product, val qty: Int)
data class Transaction(val id: String, val date: Long, val items: List<CartLine>, val total: Long, val paid: Long, val method: String, val note: String = "")

private fun rupiah(v: Long) = "Rp" + String.format(Locale("id", "ID"), "%,d", v).replace(',', '.')
private fun dateText(t: Long, pattern: String = "dd MMM yyyy HH:mm") = SimpleDateFormat(pattern, Locale("id", "ID")).format(Date(t))

@Composable fun KasirApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("kasir_rumah_kopi", Context.MODE_PRIVATE) }
    var businessName by remember { mutableStateOf(prefs.getString("business", "Rumah Kopi") ?: "Rumah Kopi") }
    var products by remember { mutableStateOf(loadProducts(prefs)) }
    var transactions by remember { mutableStateOf(loadTransactions(prefs)) }
    var cart by remember { mutableStateOf(listOf<CartLine>()) }
    var tab by remember { mutableStateOf("Dashboard") }
    var payment by remember { mutableStateOf("Tunai") }
    var paidText by remember { mutableStateOf("") }
    var receipt by remember { mutableStateOf<Transaction?>(null) }
    var productDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Product?>(null) }
    var toast by remember { mutableStateOf("") }
    var reportMonth by remember { mutableStateOf(SimpleDateFormat("yyyy-MM", Locale.US).format(Date())) }
    val adapter = BluetoothAdapter.getDefaultAdapter()
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun saveProducts() { prefs.edit().putString("products", JSONArray().apply { products.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("category",it.category).put("price",it.price).put("emoji",it.emoji)) } }.toString()).apply() }
    fun saveTransactions() { prefs.edit().putString("transactions", JSONArray().apply { transactions.forEach { tx -> put(JSONObject().put("id",tx.id).put("date",tx.date).put("total",tx.total).put("paid",tx.paid).put("method",tx.method).put("note",tx.note).put("items",JSONArray().apply { tx.items.forEach { put(JSONObject().put("name",it.product.name).put("category",it.product.category).put("price",it.product.price).put("emoji",it.product.emoji).put("qty",it.qty)) } }) ) } }.toString()).apply() }
    val total = cart.sumOf { it.product.price * it.qty }
    val paid = paidText.toLongOrNull() ?: if(payment == "Bayar nanti") 0L else if(payment != "Tunai") total else 0L
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val todays = transactions.filter { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.date)) == today }
    val monthTx = transactions.filter { SimpleDateFormat("yyyy-MM", Locale.US).format(Date(it.date)) == reportMonth }

    MaterialTheme(colorScheme = lightColorScheme(primary=Coffee, secondary=Gold, background=Cream, surface=Paper, onPrimary=Color.White, onSurface=Ink)) {
        Scaffold(containerColor=Cream, topBar={
            Row(Modifier.fillMaxWidth().background(Coffee).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo_rumah_kopi), null, Modifier.size(48.dp))
                Column(Modifier.weight(1f).padding(start=10.dp)) { Text(businessName, color=Color.White, fontWeight=FontWeight.Bold, fontSize=20.sp); Text(dateText(System.currentTimeMillis(), "EEEE, dd MMMM yyyy"), color=Color(0xFFFFE6B8), fontSize=12.sp) }
                Text("RK", color=Gold, fontWeight=FontWeight.Black, fontSize=18.sp)
            }
        }, bottomBar={
            NavigationBar(containerColor=Paper) {
                listOf("Dashboard","Kasir","Produk","Riwayat","Laporan","Pengaturan").forEach { label ->
                    val icon = when(label) { "Dashboard"->Icons.Default.Home; "Kasir"->Icons.Default.PointOfSale; "Produk"->Icons.Default.Inventory2; "Riwayat"->Icons.Default.ReceiptLong; "Laporan"->Icons.Default.Assessment; else->Icons.Default.Settings }
                    NavigationBarItem(selected=tab==label, onClick={tab=label}, icon={Icon(icon, label)}, label={Text(label, fontSize=9.sp)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Coffee, selectedTextColor=Coffee, indicatorColor=Color(0xFFEBD6A8)))
                }
            }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                when(tab) {
                    "Dashboard" -> DashboardScreen(businessName, todays.sumOf{it.total}, todays.size, products.size, transactions.size, onCashier={tab="Kasir"})
                    "Kasir" -> CashierScreen(products, cart, total, payment, paidText, {payment=it; if(it!="Tunai") paidText=total.toString()}, {paidText=it}, {p -> cart = if(cart.any{it.product.id==p.id}) cart.map{if(it.product.id==p.id) it.copy(qty=it.qty+1) else it} else cart+CartLine(p,1)}, {id -> cart=cart.map{if(it.product.id==id)it.copy(qty=it.qty-1)else it}.filter{it.qty>0}}, {id -> cart=cart.filter{it.product.id!=id}}, {cart=emptyList();paidText=""}, { 
                        if(cart.isNotEmpty() && (payment!="Tunai" || paid>=total)) { val tx=Transaction(UUID.randomUUID().toString(),System.currentTimeMillis(),cart,total,paid,payment); transactions=transactions+tx; saveTransactions(); receipt=tx; cart=emptyList(); paidText="" } else toast="Uang pembayaran belum cukup"
                    }, {tab="Pengaturan"})
                    "Produk" -> ProductScreen(products, {editing=it;productDialog=true}, {products=products.filterNot{p->p.id==it.id};saveProducts()}, {editing=null;productDialog=true})
                    "Riwayat" -> HistoryScreen(transactions.reversed(), {receipt=it})
                    "Laporan" -> ReportsScreen(monthTx, reportMonth, {reportMonth=it}, transactions)
                    else -> SettingsScreen(businessName, {businessName=it;prefs.edit().putString("business",it).apply()}, { toast="Data tersimpan di perangkat ini" }, {requestBluetooth(context, adapter, permissionLauncher) { toast=it }})
                }
            }
        }
        if(productDialog) ProductDialog(editing, { name,category,price,emoji -> val p=Product(editing?.id ?: UUID.randomUUID().toString(),name,category,price,emoji);products=if(editing==null)products+p else products.map{if(it.id==p.id)p else it};saveProducts();productDialog=false;editing=null }, {productDialog=false;editing=null})
        receipt?.let { ReceiptDialog(it,businessName,{receipt=null},{requestBluetooth(context,adapter,permissionLauncher){ msg -> printReceipt(context,it,businessName,msg);toast=msg }}) }
        if(toast.isNotBlank()) AlertDialog(onDismissRequest={toast=""}, title={Text("Kasir Rumah Kopi")}, text={Text(toast)}, confirmButton={TextButton(onClick={toast=""}){Text("OK")}})
    }
}

@Composable private fun DashboardScreen(name:String, sales:Long, count:Int, productCount:Int, totalTx:Int, onCashier:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Selamat datang di $name", fontWeight=FontWeight.Bold,fontSize=22.sp,color=Coffee); Text("Ringkasan penjualan hari ini",color=Muted) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { StatCard("Omzet hari ini",rupiah(sales),Modifier.weight(1f));StatCard("Transaksi",count.toString(),Modifier.weight(1f)) } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { StatCard("Menu",productCount.toString(),Modifier.weight(1f));StatCard("Total transaksi",totalTx.toString(),Modifier.weight(1f)) } }
        item { Button(onClick=onCashier,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Coffee)) { Icon(Icons.Default.PointOfSale,null);Spacer(Modifier.width(8.dp));Text("Mulai transaksi") } }
        item { Card(colors=CardDefaults.cardColors(containerColor=Paper)) { Column(Modifier.padding(16.dp)) { Text("Tips",fontWeight=FontWeight.Bold,color=Coffee);Text("Tambahkan menu dan harga di tab Produk. Transaksi tersimpan lokal di perangkat Anda.",color=Muted) } } }
    }
}
@Composable private fun StatCard(label:String,value:String,modifier:Modifier=Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=Paper),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(14.dp)){Text(label,color=Muted,fontSize=12.sp);Text(value,fontSize=20.sp,fontWeight=FontWeight.Bold,color=Coffee)}}}

@Composable private fun CashierScreen(products:List<Product>,cart:List<CartLine>,total:Long,payment:String,paidText:String,onPayment:(String)->Unit,onPaid:(String)->Unit,onAdd:(Product)->Unit,onMinus:(String)->Unit,onRemove:(String)->Unit,onClear:()->Unit,onCheckout:()->Unit,onManage:()->Unit){
    var category by remember{mutableStateOf("Semua")};var search by remember{mutableStateOf("")};var showCart by remember{mutableStateOf(false)}
    val cats=listOf("Semua","Minuman","Makanan","Snack","Lainnya")
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){cats.forEach{FilterChip(selected=category==it,onClick={category=it},label={Text(it)})}}
        OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),label={Text("Cari menu")},singleLine=true)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("Menu",fontWeight=FontWeight.Bold);TextButton(onClick=onManage){Text("+ Tambah menu")}}
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) { items(products.filter{(category=="Semua"||it.category==category)&&it.name.contains(search,true)}) { p -> Card(onClick={onAdd(p)},colors=CardDefaults.cardColors(containerColor=Paper)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(p.emoji,fontSize=26.sp);Column(Modifier.weight(1f).padding(start=10.dp)){Text(p.name,fontWeight=FontWeight.SemiBold);Text(p.category,fontSize=12.sp,color=Muted)};Text(rupiah(p.price),fontWeight=FontWeight.Bold,color=Coffee)}} } }
        Card(colors=CardDefaults.cardColors(containerColor=Paper)){Column(Modifier.padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Keranjang (${cart.sumOf{it.qty}})",fontWeight=FontWeight.Bold);TextButton(onClick={showCart=!showCart}){Text(if(showCart)"Sembunyikan" else "Lihat")}};Text("Total: ${rupiah(total)}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Coffee);if(showCart){cart.forEach{line->Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Text("${line.product.name} × ${line.qty}",Modifier.weight(1f));Text(rupiah(line.product.price*line.qty));TextButton(onClick={onMinus(line.product.id)}){Text("−")};TextButton(onClick={onAdd(line.product)}){Text("+")};TextButton(onClick={onRemove(line.product.id)}){Text("×")}}}}
                Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf("Tunai","Transfer","QRIS","Bayar nanti").forEach{FilterChip(selected=payment==it,onClick={onPayment(it)},label={Text(it)})}}
                if(payment=="Tunai")OutlinedTextField(paidText,onPaid,Modifier.fillMaxWidth(),label={Text("Uang diterima")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
                if(payment=="Tunai"&&paidText.toLongOrNull()!=null)Text("Kembalian: ${rupiah((paidText.toLongOrNull()?:0)-total)}",fontWeight=FontWeight.SemiBold,color=Coffee)
                Button(onClick=onCheckout,Modifier.fillMaxWidth(),enabled=cart.isNotEmpty()&&(payment!="Tunai"||(paidText.toLongOrNull()?:0)>=total),colors=ButtonDefaults.buttonColors(containerColor=Coffee)){Text("Selesaikan & Preview Struk")}
                TextButton(onClick=onClear,Modifier.align(Alignment.End)){Text("Kosongkan keranjang")}
            }}
    }
}
@Composable private fun ProductScreen(products:List<Product>,onEdit:(Product)->Unit,onDelete:(Product)->Unit,onAdd:()->Unit){Column(Modifier.fillMaxSize().padding(12.dp)){Button(onClick=onAdd,colors=ButtonDefaults.buttonColors(containerColor=Coffee)){Icon(Icons.Default.Add,null);Text("Tambah produk")};LazyColumn{items(products){p->Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Paper)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(p.emoji,fontSize=24.sp);Column(Modifier.weight(1f).padding(start=8.dp)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.category} • ${rupiah(p.price)}",color=Muted)};IconButton(onClick={onEdit(p)}){Icon(Icons.Default.Edit,"Edit")};IconButton(onClick={onDelete(p)}){Icon(Icons.Default.Delete,"Hapus")}}}}}}}
@Composable private fun HistoryScreen(tx:List<Transaction>,onReceipt:(Transaction)->Unit){LazyColumn(Modifier.fillMaxSize().padding(12.dp)){items(tx){t->Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Paper),onClick={onReceipt(t)}){Column(Modifier.padding(14.dp)){Text(dateText(t.date),fontSize=12.sp,color=Muted);Text("${t.items.sumOf{it.qty}} item • ${t.method}",fontWeight=FontWeight.SemiBold);Text(rupiah(t.total),fontWeight=FontWeight.Bold,color=Coffee);Text("ID ${t.id.take(8)}",fontSize=11.sp,color=Muted)}}}}}
@Composable private fun ReportsScreen(tx:List<Transaction>,month:String,onMonth:(String)->Unit,all:List<Transaction>){val daily=tx.filter{SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(it.date))==SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())};Column(Modifier.fillMaxSize().padding(16.dp)){Text("Laporan penjualan",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Coffee);OutlinedTextField(month,onMonth,label={Text("Bulan (YYYY-MM)")},modifier=Modifier.fillMaxWidth());Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("Omzet bulan",rupiah(tx.sumOf{it.total}),Modifier.weight(1f));StatCard("Transaksi",tx.size.toString(),Modifier.weight(1f))};Spacer(Modifier.height(10.dp));StatCard("Omzet hari ini",rupiah(daily.sumOf{it.total}),Modifier.fillMaxWidth());Text("Transaksi bulan ini",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));LazyColumn{items(tx.sortedByDescending{it.date}){t->ListItem(headlineContent={Text(dateText(t.date))},supportingContent={Text(t.method+" • "+t.items.sumOf{it.qty}+" item")},trailingContent={Text(rupiah(t.total),fontWeight=FontWeight.Bold)})}};TextButton(onClick={exportTransactions(all)}){Text("Bagikan / Ekspor CSV")}}}
@Composable private fun SettingsScreen(name:String,onName:(String)->Unit,onSave:()->Unit,onBluetooth:()->Unit){var edit by remember{name};Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Card(colors=CardDefaults.cardColors(containerColor=Paper)){Column(Modifier.padding(16.dp)){Image(painterResource(R.drawable.logo_rumah_kopi),null,Modifier.fillMaxWidth().height(150.dp));Text("Identitas usaha",fontWeight=FontWeight.Bold,color=Coffee);OutlinedTextField(edit,{edit=it},Modifier.fillMaxWidth(),label={Text("Nama usaha")});Button(onClick={onName(edit);onSave()},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Coffee)){Text("Simpan nama")}}};Card(colors=CardDefaults.cardColors(containerColor=Paper)){Column(Modifier.padding(16.dp)){Text("Printer thermal Bluetooth",fontWeight=FontWeight.Bold,color=Coffee);Text("Pair printer thermal dari Pengaturan Bluetooth Android terlebih dahulu.",color=Muted);Button(onClick=onBluetooth,colors=ButtonDefaults.buttonColors(containerColor=Coffee)){Icon(Icons.Default.Print,null);Text("Cetak struk terakhir / tes Bluetooth")}}};Text("Data transaksi dan menu disimpan offline pada perangkat ini.",color=Muted)}}

@Composable private fun ProductDialog(product:Product?,onSave:(String,String,Long,String)->Unit,onCancel:()->Unit){var name by remember{mutableStateOf(product?.name?:"")};var price by remember{mutableStateOf(product?.price?.toString()?:"")};var category by remember{mutableStateOf(product?.category?:"Minuman")};var emoji by remember{mutableStateOf(product?.emoji?:"☕")};AlertDialog(onDismissRequest=onCancel,title={Text(if(product==null)"Tambah produk" else "Edit produk")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text("Nama produk")});OutlinedTextField(price,{price=it.filter(Char::isDigit)},label={Text("Harga")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(emoji,{emoji=it},label={Text("Emoji")});Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("Minuman","Makanan","Snack","Lainnya").forEach{FilterChip(selected=category==it,onClick={category=it},label={Text(it)})}}}},confirmButton={TextButton(onClick={if(name.isNotBlank()&&(price.toLongOrNull()?:0)>0)onSave(name,category,price.toLong(),emoji)}){Text("Simpan")}},dismissButton={TextButton(onClick=onCancel){Text("Batal")}})}
@Composable private fun ReceiptDialog(tx:Transaction,business:String,onClose:()->Unit,onPrint:()->Unit){AlertDialog(onDismissRequest=onClose,title={Text("Preview struk")},text={Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState())){Text(business,fontWeight=FontWeight.Bold,fontSize=20.sp);Text("${dateText(tx.date)}\nNo: ${tx.id.take(8)}\n--------------------------------");tx.items.forEach{Text("${it.product.name} x${it.qty}");Text("${rupiah(it.product.price)}  ${rupiah(it.product.price*it.qty)}")};Text("--------------------------------");Text("TOTAL: ${rupiah(tx.total)}",fontWeight=FontWeight.Bold);Text("Pembayaran: ${tx.method}");Text("Dibayar: ${rupiah(tx.paid)}");Text("Kembali: ${rupiah(tx.paid-tx.total)}");Text("\nTerima kasih, selamat menikmati kopi!")}},confirmButton={TextButton(onClick=onPrint){Text("Cetak Bluetooth")}},dismissButton={TextButton(onClick=onClose){Text("Tutup")}})}

private fun loadProducts(prefs:android.content.SharedPreferences):List<Product>{val s=prefs.getString("products",null)?:return listOf(Product(name="Kopi Susu",category="Minuman",price=18000,emoji="☕"),Product(name="Americano",category="Minuman",price=15000,emoji="☕"),Product(name="Teh Manis",category="Minuman",price=8000,emoji="🫖"),Product(name="Roti Bakar",category="Makanan",price=15000,emoji="🍞"),Product(name="Pisang Goreng",category="Snack",price=12000,emoji="🍌"));return runCatching{val a=JSONArray(s);(0 until a.length()).map{val o=a.getJSONObject(it);Product(o.getString("id"),o.getString("name"),o.getString("category"),o.getLong("price"),o.optString("emoji","☕"))}}.getOrDefault(emptyList())}
private fun loadTransactions(prefs:android.content.SharedPreferences):List<Transaction>{val s=prefs.getString("transactions",null)?:return emptyList();return runCatching{val a=JSONArray(s);(0 until a.length()).map{val o=a.getJSONObject(it);val items=o.getJSONArray("items");Transaction(o.getString("id"),o.getLong("date"),(0 until items.length()).map{val x=items.getJSONObject(it);CartLine(Product(name=x.getString("name"),category=x.getString("category"),price=x.getLong("price"),emoji=x.optString("emoji","☕")),x.getInt("qty"))},o.getLong("total"),o.getLong("paid"),o.getString("method"),o.optString("note"))}}.getOrDefault(emptyList())}
private fun requestBluetooth(context:Context,adapter:BluetoothAdapter?,permissionLauncher: androidx.activity.result.ActivityResultLauncher<String>,callback:(String)->Unit){if(adapter==null){callback("Bluetooth tidak tersedia pada perangkat ini.");return};if(Build.VERSION.SDK_INT>=31&&ContextCompat.checkSelfPermission(context,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT);callback("Izinkan Bluetooth lalu tekan cetak lagi.");return};val devices=runCatching{adapter.bondedDevices}.getOrDefault(emptySet());if(devices.isEmpty()){callback("Belum ada printer yang dipasangkan. Pair printer thermal di pengaturan Bluetooth Android.");return};callback("Printer terpasang: "+devices.joinToString { it.name ?: it.address }+". Tekan Cetak Bluetooth dari preview struk untuk mengirim struk.")}
private fun printReceipt(context:Context,tx:Transaction,business:String,message:String){
    val adapter=BluetoothAdapter.getDefaultAdapter() ?: return
    if(Build.VERSION.SDK_INT>=31 && ContextCompat.checkSelfPermission(context,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){ android.widget.Toast.makeText(context,"Izinkan Bluetooth lalu tekan cetak lagi",android.widget.Toast.LENGTH_LONG).show();return }
    val device=runCatching{adapter.bondedDevices.firstOrNull()}.getOrNull()
    if(device==null){android.widget.Toast.makeText(context,"Pair printer thermal terlebih dahulu melalui Bluetooth Android",android.widget.Toast.LENGTH_LONG).show();return}
    Thread { var socket:BluetoothSocket?=null;try{
        socket=device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));adapter.cancelDiscovery();socket.connect();val out=socket.outputStream
        out.write(byteArrayOf(0x1B,0x40));out.write(byteArrayOf(0x1B,0x61,0x01))
        out.write((business+"\n").toByteArray(Charsets.UTF_8));out.write("STRUK PEMBELIAN\n".toByteArray());out.write((dateText(tx.date)+"\n").toByteArray());out.write("--------------------------------\n".toByteArray())
        out.write(byteArrayOf(0x1B,0x61,0x00));tx.items.forEach{line->out.write((line.product.name+" x"+line.qty+"\n").toByteArray());out.write((rupiah(line.product.price*line.qty)+"\n").toByteArray())}
        out.write("--------------------------------\n".toByteArray());out.write(("TOTAL: "+rupiah(tx.total)+"\n").toByteArray());out.write(("Bayar: "+tx.method+"\n").toByteArray());out.write(("Dibayar: "+rupiah(tx.paid)+"\n").toByteArray());out.write(("Kembali: "+rupiah(tx.paid-tx.total)+"\n\nTerima kasih!\n\n\n").toByteArray());out.write(byteArrayOf(0x1D,0x56,0x41,0x03));out.flush()
        android.os.Handler(android.os.Looper.getMainLooper()).post{android.widget.Toast.makeText(context,"Struk dikirim ke ${device.name}",android.widget.Toast.LENGTH_LONG).show()}
    }catch(e:Exception){android.os.Handler(android.os.Looper.getMainLooper()).post{android.widget.Toast.makeText(context,"Gagal mencetak: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}}finally{runCatching{socket?.close()}} }.start()
}
private fun exportTransactions(tx:List<Transaction>){/* CSV export planned; records remain saved locally. */}
